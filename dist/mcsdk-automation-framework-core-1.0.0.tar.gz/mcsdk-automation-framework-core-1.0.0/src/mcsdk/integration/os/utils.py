import os


def chdir(directory):
    os.chdir(directory)
