# MCSDK-Automation-Framework-Core
This will serve as a core repository for the MC SDK Automation Framework. This repo will have the Master Open API Specification file, the swagger CLI code, the CI scripts and the language specific mustache files
